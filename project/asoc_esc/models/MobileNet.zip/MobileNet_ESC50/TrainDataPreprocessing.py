#!/usr/bin/env python
# coding: utf-8

# In[ ]:


#model套件
import torch
from torch.utils.data import Dataset

#聲音處理套件
import librosa
#資料處理套件
import pandas as pd
import os

# In[ ]:

#DataSetPath
PATH_HAED = "/home/s1811032014/code/ESC-50-master/"
#音訊資訊CSV檔位置 
DATA_CSV_PATH = PATH_HAED + "ESC-50-master/meta/esc50.csv"
#音訊存放位置
DATA_PATH = PATH_HAED + "ESC-50-master/audio/"

def loadDataESC50(soundLength):
    fileX = "dataX_ESC50_" + str(soundLength) + ".pt"
    fileY = "dataY_ESC50_" + str(soundLength) + ".pt"
    
    # 獲取當前目錄
    current_dir = os.getcwd()

    # 獲取父目錄
    parent_dir = os.path.dirname(current_dir)

    # 構建父目錄中文件的路徑
    fileX_path = os.path.join(parent_dir, fileX)
    fileY_path = os.path.join(parent_dir, fileY)
    
    if os.path.exists(fileX_path) and os.path.exists(fileY_path):
        # 兩個檔案都存在，進行下一步操作
        
        dataX_Fold = torch.load(fileX_path)
        dataY_Fold = torch.load(fileY_path)
        
        return dataX_Fold, dataY_Fold
    else:
        # 至少一個檔案不存在
        if not os.path.exists(fileX_path):
            print(f"{fileX} 不存在。")
        if not os.path.exists(fileY_path):
            print(f"{fileY} 不存在。")
    
        data_path = DATA_PATH
        data_csv_path = DATA_CSV_PATH
        dataX_Fold = []
        dataY_Fold = []

        #讀取CSV檔
        df = pd.read_csv(data_csv_path)
        #計數
        count = 0

        for Fold in range(1, 6, 1):
            #初始化
            dataX = []
            dataY = []
            #篩選資料
            sound_df = df[df.fold == Fold]
            #轉換train資料/添加標籤
            for data in sound_df.itertuples():
                sig, sr = librosa.load(data_path+data[1])
                for i in range((6-soundLength)):
                    sound = sig[i*sr : int((i+soundLength)*sr)]
                    dataX.append(sound)
                    dataY.append(data[3])       
                count +=1
                print("{:.3f}".format(100 * count / len(df))+"%", end='\r')
            dataX_Fold.append(dataX)
            dataY_Fold.append(dataY)

        #通通轉成 torch 的 tensor 形式
        dataX_Fold = torch.Tensor(dataX_Fold)
        dataY_Fold = torch.Tensor(dataY_Fold).type(torch.LongTensor)
        
        #存起來
        torch.save(dataX_Fold, fileX_path)
        torch.save(dataY_Fold, fileY_path)

        # 完成時打印最終消息
        print("Progress: 100% - Completed")
        return dataX_Fold, dataY_Fold

class CustomDataset(Dataset):
    def __init__(self, inputDataX, inputDataY, fold, isTrain):
        #防止範圍錯誤
        if(fold>5 or fold <1):
            raise ValueError("Fold範圍錯誤")
            
        #資料初始化
        self.dataX = []
        self.dataY = []
        
        # True:訓練資料  False:測試資料
        if isTrain:
            for Fold in range(1, 6, 1):
                if(Fold != fold):
                    for X in inputDataX[Fold-1]:
                        self.dataX.append(X)
                    for Y in inputDataY[Fold-1]:
                        self.dataY.append(Y)
        else:
            self.dataX = inputDataX[fold-1]
            self.dataY = inputDataY[fold-1]

    def __len__(self):
        return len(self.dataX)
    
    def __getitem__(self, index):
        # 根據索引返回單個樣本及其標籤
        data = self.dataX[index]
        label = self.dataY[index]
        
        return data, label

