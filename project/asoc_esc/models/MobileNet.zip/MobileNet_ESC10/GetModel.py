#!/usr/bin/env python
# coding: utf-8

# In[1]:


import torch
import torch.nn as nn
import torchvision.models as models
from models.MobileNetV3 import get_model

# In[2]:
seed = 1145114
#設置隨機種子
torch.manual_seed(seed)
torch.cuda.manual_seed(seed)
torch.cuda.manual_seed_all(seed)

def getModel(num_classes):
    #載入模型
    model = get_model(num_classes=num_classes, width_mult=4.0, pretrained_name="mn40_as_ext")
    return model

