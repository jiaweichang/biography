#!/usr/bin/env python
# coding: utf-8

# In[1]:


import torch
import torch.nn as nn
import torchvision.models as models


# In[2]:
seed = 114514
#設置隨機種子
torch.manual_seed(seed)
torch.cuda.manual_seed(seed)
torch.cuda.manual_seed_all(seed)

def getModel(num_classes):
    #載入模型
    model = models.resnet18()
    
    # 修改模型的第一層輸入通道數
    model.conv1 = torch.nn.Conv2d(1, 64, kernel_size=7, stride=2, padding=3, bias=False)
    
    # 取得模型的分類器
    classifier = model.fc
    # 修改分類器的屬性
    in_features = classifier.in_features  # 原分類器的輸入維度
    new_classifier = nn.Linear(in_features, num_classes)  # 創建新的分類器
    # 將修改後的分類器設置回模型
    model.fc = new_classifier
    
    return model

