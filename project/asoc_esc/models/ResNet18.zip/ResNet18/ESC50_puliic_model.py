#!/usr/bin/env python
# coding: utf-8

# In[1]:


#model套件
import torch
from torch import nn as nn


# In[2]:


#LeNet5模型
class LeNet(nn.Module):
    def __init__(self, nums_class=10):
        super(LeNet,self).__init__()
        
        #卷基層
        self.conv_layer = nn.Sequential(
            nn.Conv2d(in_channels=1,out_channels=16,kernel_size=5,stride=1,padding=0),
            nn.MaxPool2d(kernel_size=2, stride=2, padding=0),
            nn.Conv2d(in_channels=16,out_channels=32,kernel_size=5,stride=1,padding=0),
            nn.MaxPool2d(kernel_size=2, stride=2, padding=0)
        )
        
        #全連接層
        self.fullconn_layer = nn.Sequential(
            nn.AdaptiveAvgPool2d(1),
            nn.Flatten(),
            nn.Linear(32,120),
            nn.ReLU(),
            nn.Linear(120,84),
            nn.ReLU(),
            nn.Linear(84,nums_class)           
        )
        
    def forward(self,x):
        output = self.conv_layer(x)
        output = self.fullconn_layer(output)
        return output


# In[3]:


#注意力模塊
class AttentionBlock(nn.Module):
    def __init__(self):
        super(AttentionBlock, self).__init__()
    def forward(self, x):
        #BCHW
        B = x.shape[0]
        C = x.shape[1]
        H = x.shape[2]
        W = x.shape[3]
        outputs = torch.zeros((B, C, H, W), device=device)
        for b in range(B):
            a2 = x[b] #CHW
            a2 = a2.permute(1,2,0) #HWC
            a2 = torch.reshape(a2, (H*W, C)) # NC N=H*W
            
            a3 = torch.reshape(x[b], (C, H*W)) # CN N=H*W
            
            a4 = torch.reshape(x[b], (C, H*W)) # CN N=H*W
            
            a5 = torch.matmul(a2, a3) #NN
            a5 = nn.Softmax(dim=1)(a5) #NN
                    
            a6 = torch.matmul(a4, a5) #CN CN=CN*NN
            a6 = torch.reshape(a6, (C, H, W)) #CHW
                
            outputs[b] = torch.add(x[b], a6) #BCHW
        return outputs
    
#殘差網路模塊
class ResBlock(nn.Module):
    def __init__(self, in_channels, out_channels, downsample):
        super().__init__()
        if downsample:
            self.conv1 = nn.Conv2d(in_channels, out_channels, kernel_size=3, stride=2, padding=1)
            self.shortcut = nn.Sequential(
                nn.Conv2d(in_channels, out_channels, kernel_size=1, stride=2),
                nn.BatchNorm2d(out_channels)
            )
        else:
            self.conv1 = nn.Conv2d(in_channels, out_channels, kernel_size=3, stride=1, padding=1)
            self.shortcut = nn.Sequential()

        self.conv2 = nn.Conv2d(out_channels, out_channels, kernel_size=3, stride=1, padding=1)
        self.bn1 = nn.BatchNorm2d(out_channels)
        self.bn2 = nn.BatchNorm2d(out_channels)

    def forward(self, input):
        shortcut = self.shortcut(input)
        input = nn.ReLU()(self.bn1(self.conv1(input)))
        input = nn.ReLU()(self.bn2(self.conv2(input)))
        input = input + shortcut
        return nn.ReLU()(input)
    
#ResNet_18+注意力機制 模型
class ResNet_18(nn.Module):
    def __init__(self, nums_class=10):
        super(ResNet_18, self).__init__()
        
        self.layer_0 = nn.Sequential(
            # width_of_output = (width_of_input - filter_size + 2*padding)/stride + 1
            nn.Conv2d(in_channels = 1, out_channels = 64, kernel_size = (7,7), stride = (2,2), padding = 3),
            nn.MaxPool2d(kernel_size=3, stride=2, padding=1),
            nn.BatchNorm2d(64),
            nn.ReLU()
        )
        
        #殘差層
        #-----------------------------------------------------
        self.layer_1 = nn.Sequential(
            ResBlock(64, 64, downsample=False),
            ResBlock(64, 64, downsample=False)
        )
        
        self.layer_2 = nn.Sequential(
            ResBlock(64, 128, downsample=True),
            ResBlock(128, 128, downsample=False)
        )
        
        self.layer_3 = nn.Sequential(
            ResBlock(128, 256, downsample=True),
            ResBlock(256, 256, downsample=False)
        )
        
        self.layer_4 = nn.Sequential(
            ResBlock(256, 512, downsample=True),
            ResBlock(512, 512, downsample=False)
        )
        #-----------------------------------------------------
        
        #注意力模塊
        #self.layer_5 = AttentionBlock()
        
        self.layer_6 = nn.Sequential(
            nn.AdaptiveAvgPool2d(1),
            nn.Flatten(),
            #nn.Dropout(p=0.3),
            nn.Linear(512, 64),
            #nn.Dropout(p=0.3),
            nn.Linear(64, nums_class)
        )
        
    def forward(self, x):
        x = self.layer_0(x)
        x = self.layer_1(x)
        x = self.layer_2(x)
        x = self.layer_3(x)
        x = self.layer_4(x)
        #x = self.layer_5(x)
        x = self.layer_6(x)
        return x

