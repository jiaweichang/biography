#!/usr/bin/env python
# coding: utf-8

# In[3]:


#model套件
import torch


# In[4]:


#音訊存放位置
ESC_DATA_PATH = "Preprocessing/ESC/Fold"
C_DATA_PATH = "Preprocessing/Chainsaw/"

def getTrainDataset(fold, soundLength, labelnum):
    x_train_path = ESC_DATA_PATH + str(fold) + "/" + str(soundLength) + "s/x_train.pt"
    y_train_path = ESC_DATA_PATH + str(fold) + "/" + str(soundLength) + "s/y_train_" + str(labelnum) + ".pt"
    x_val_path = ESC_DATA_PATH + str(fold) + "/" + str(soundLength) + "s/x_val.pt"
    y_val_path = ESC_DATA_PATH + str(fold) + "/" + str(soundLength) + "s/y_val_" + str(labelnum) + ".pt"
    
    x_train = torch.load(x_train_path)
    y_train = torch.load(y_train_path)
    x_val = torch.load(x_val_path)
    y_val = torch.load(y_val_path)
    
    #打包
    train = torch.utils.data.TensorDataset(x_train,y_train)
    val = torch.utils.data.TensorDataset(x_val,y_val)
    
    return train, val

def getTrainDataset_val135(fold, soundLength, labelnum):
    x_train_path = ESC_DATA_PATH + str(fold) + "/" + str(soundLength) + "s/x_train.pt"
    y_train_path = ESC_DATA_PATH + str(fold) + "/" + str(soundLength) + "s/y_train_" + str(labelnum) + ".pt"
    x_val1_path = ESC_DATA_PATH + str(fold) + "/" + str(1) + "s/x_val.pt"
    y_val1_path = ESC_DATA_PATH + str(fold) + "/" + str(1) + "s/y_val_" + str(labelnum) + ".pt"
    x_val3_path = ESC_DATA_PATH + str(fold) + "/" + str(3) + "s/x_val.pt"
    y_val3_path = ESC_DATA_PATH + str(fold) + "/" + str(3) + "s/y_val_" + str(labelnum) + ".pt"
    x_val5_path = ESC_DATA_PATH + str(fold) + "/" + str(5) + "s/x_val.pt"
    y_val5_path = ESC_DATA_PATH + str(fold) + "/" + str(5) + "s/y_val_" + str(labelnum) + ".pt"
    
    x_train = torch.load(x_train_path)
    y_train = torch.load(y_train_path)
    x_val1 = torch.load(x_val1_path)
    y_val1 = torch.load(y_val1_path)
    x_val3 = torch.load(x_val3_path)
    y_val3 = torch.load(y_val3_path)
    x_val5 = torch.load(x_val5_path)
    y_val5 = torch.load(y_val5_path)
    
    #打包
    train = torch.utils.data.TensorDataset(x_train,y_train)
    val1 = torch.utils.data.TensorDataset(x_val1,y_val1)
    val3 = torch.utils.data.TensorDataset(x_val3,y_val3)
    val5 = torch.utils.data.TensorDataset(x_val5,y_val5)
    
    return train, val1, val3, val5

def getTestDataset(soundLength):
    x_test_path = C_DATA_PATH + str(soundLength) + "s/x_test.pt"
    y_test_path = C_DATA_PATH + str(soundLength) + "s/y_test.pt"
    
    x_test = torch.load(x_test_path)
    y_test = torch.load(y_test_path)
    
    #打包
    test = torch.utils.data.TensorDataset(x_test,y_test)    
    
    return test


#ESC10 1D音訊存放位置
ESC_DATA_PATH_1D = "Preprocessing/ESC_1D/Fold"

def getTrainDataset_1D(fold, soundLength, labelnum):
    x_train_path = ESC_DATA_PATH_1D + str(fold) + "/" + str(soundLength) + "s/x_train.pt"
    y_train_path = ESC_DATA_PATH_1D + str(fold) + "/" + str(soundLength) + "s/y_train_" + str(labelnum) + ".pt"
    x_val_path = ESC_DATA_PATH_1D + str(fold) + "/" + str(soundLength) + "s/x_val.pt"
    y_val_path = ESC_DATA_PATH_1D + str(fold) + "/" + str(soundLength) + "s/y_val_" + str(labelnum) + ".pt"
    
    x_train = torch.load(x_train_path)
    y_train = torch.load(y_train_path)
    x_val = torch.load(x_val_path)
    y_val = torch.load(y_val_path)
    
    #打包
    train = torch.utils.data.TensorDataset(x_train,y_train)
    val = torch.utils.data.TensorDataset(x_val,y_val)
    
    return train, val

def getTrainDataset_val135_1D(fold, soundLength, labelnum):
    x_train_path = ESC_DATA_PATH_1D + str(fold) + "/" + str(soundLength) + "s/x_train.pt"
    y_train_path = ESC_DATA_PATH_1D + str(fold) + "/" + str(soundLength) + "s/y_train_" + str(labelnum) + ".pt"
    x_val1_path = ESC_DATA_PATH_1D + str(fold) + "/" + str(1) + "s/x_val.pt"
    y_val1_path = ESC_DATA_PATH_1D + str(fold) + "/" + str(1) + "s/y_val_" + str(labelnum) + ".pt"
    x_val3_path = ESC_DATA_PATH_1D + str(fold) + "/" + str(3) + "s/x_val.pt"
    y_val3_path = ESC_DATA_PATH_1D + str(fold) + "/" + str(3) + "s/y_val_" + str(labelnum) + ".pt"
    x_val5_path = ESC_DATA_PATH_1D + str(fold) + "/" + str(5) + "s/x_val.pt"
    y_val5_path = ESC_DATA_PATH_1D + str(fold) + "/" + str(5) + "s/y_val_" + str(labelnum) + ".pt"
    
    x_train = torch.load(x_train_path)
    y_train = torch.load(y_train_path)
    x_val1 = torch.load(x_val1_path)
    y_val1 = torch.load(y_val1_path)
    x_val3 = torch.load(x_val3_path)
    y_val3 = torch.load(y_val3_path)
    x_val5 = torch.load(x_val5_path)
    y_val5 = torch.load(y_val5_path)
    
    #打包
    train = torch.utils.data.TensorDataset(x_train,y_train)
    val1 = torch.utils.data.TensorDataset(x_val1,y_val1)
    val3 = torch.utils.data.TensorDataset(x_val3,y_val3)
    val5 = torch.utils.data.TensorDataset(x_val5,y_val5)
    
    return train, val1, val3, val5

#ESC50 1D音訊存放位置
ESC50_DATA_PATH_1D = "Preprocessing/ESC50_1D/Fold"

#只抓取5秒的訓練/測試資料
def getTrainDataset_ESC50_5s_1D(fold):
    x_train_path = ESC50_DATA_PATH_1D + str(fold) + "/5s/x_train.pt"
    y_train_path = ESC50_DATA_PATH_1D + str(fold) + "/5s/y_train.pt"
    x_val_path = ESC50_DATA_PATH_1D + str(fold) + "/5s/x_val.pt"
    y_val_path = ESC50_DATA_PATH_1D + str(fold) + "/5s/y_val.pt"
    
    x_train = torch.load(x_train_path)
    y_train = torch.load(y_train_path)
    x_val = torch.load(x_val_path)
    y_val = torch.load(y_val_path)
  
    
    #打包
    train = torch.utils.data.TensorDataset(x_train,y_train)
    val = torch.utils.data.TensorDataset(x_val,y_val)
    
    return train, val

#ESC50 paper音訊存放位置
ESC50_DATA_PATH_paper = "Preprocessing/ESC50_paper/Fold"

#只抓取5秒的訓練/測試資料
def getTrainDataset_ESC50_5s_paper(fold):
    x_train_path = ESC50_DATA_PATH_paper + str(fold) + "/5s/x_train.pt"
    y_train_path = ESC50_DATA_PATH_paper + str(fold) + "/5s/y_train.pt"
    x_val_path = ESC50_DATA_PATH_paper + str(fold) + "/5s/x_val.pt"
    y_val_path = ESC50_DATA_PATH_paper + str(fold) + "/5s/y_val.pt"
    
    x_train = torch.load(x_train_path)
    y_train = torch.load(y_train_path)
    x_val = torch.load(x_val_path)
    y_val = torch.load(y_val_path)
  
    
    #打包
    train = torch.utils.data.TensorDataset(x_train,y_train)
    val = torch.utils.data.TensorDataset(x_val,y_val)
    
    return train, val
