"""
Recipes for SDN
"""
