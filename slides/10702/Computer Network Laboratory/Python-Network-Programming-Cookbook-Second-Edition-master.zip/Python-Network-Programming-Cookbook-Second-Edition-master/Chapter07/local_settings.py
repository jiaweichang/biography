#!/usr/bin/env python
# Python Network Programming Cookbook -- Chapter - 8
# This program is optimized for Python 2.7.
# It may run on any other version with/without modifications.

# Make a copy of this file as local_settings.py
# FILL IN THE VARIABLES BELOW WITH YOUR PERSONAL INFORMATION

# Amazon API stuffs
amazon_account = {
        'access_key' : '',
        'secret_key' : '',
        'affiliate_id' : ''
    }

flickr_apikey = '' 
