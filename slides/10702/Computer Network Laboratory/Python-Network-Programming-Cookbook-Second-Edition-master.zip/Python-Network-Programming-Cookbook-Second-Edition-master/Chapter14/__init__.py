"""
Recipes for BGP
"""
