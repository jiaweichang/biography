"""
Recipes for Network Modelling
"""
