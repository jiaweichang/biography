本書範例檔使用說明：

1. 建議您先在電腦端安裝雲端硬碟電腦版 (https://www.google.com/intl/zh-TW_tw/drive/download/)。

2. 本書範例檔建議存放位置：

   C:\Users\(您的使用者名稱)\Google 雲端硬碟\Colab_Notebooks\F1378

3. 完成步驟 2 後，可參考本書附錄的 A-4 頁了解如何開啟範例檔來使用。